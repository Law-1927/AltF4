# ALT F4 — Shimmer & Shield website concept

## Run it
1. Extract the ZIP.
2. Keep `index.html`, `styles.css`, `script.js`, and `bgbg.png` in the same folder.
3. Open `index.html` in a browser.

## Included
- Responsive automotive service landing page
- Black, red, and white visual theme
- User-provided ALT F4 background image
- Login and account-creation modal layouts
- Appointment request form with service, vehicle, date, and time fields
- Demo appointment requests saved in the current browser's localStorage

## Important before real deployment
This is a front-end prototype. Login and registration are visual/demo only; they do not create secure accounts. Appointment requests are saved only in the visitor's browser and are not sent to the business. A production system needs a backend, database, secure password hashing, server-side validation, session management, admin appointment review, and email/SMS notifications. Do not use localStorage as an authentication or production booking database.

The design is an original automotive-focused layout, not a copy of ECOUNT's proprietary page code or assets.
